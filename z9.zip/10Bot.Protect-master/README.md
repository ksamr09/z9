10 Akun BotProtect + 1 Akun Bot Satpam

===Bot Kris===

Versi Kris :
http://line.me/ti/p/GkwfNjoPDH
==================================

Fungsinya:

untuk protek pastinya
Admin ke kick akan di undang otomatis
bot lainya ke kick akan di undang lagi
kalau admin nyuruh nendang member, bot satpam akan masuk lewat kode qr dan terus mengkick target tsb dan left lagi
Akun utama ke kick akan di undang otomatis oleh bot lainnya
dan lain-lain
Akun kita sendiri tidak mesti di room tersebut/jadi akun kita tidak banyak room
join in my team ✰ tɛǟʍ ċʏɮɛʀ-ǟʀʍʏ ɮօt ✰


# Deploy to:
[![Deploy to Heroku](https://www.herokucdn.com/deploy/button.svg)](https://heroku.com/deploy)
